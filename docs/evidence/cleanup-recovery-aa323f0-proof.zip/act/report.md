# Local CI report

Source: `aa323f0119e2d3c475d04a30860a4c3e314620bc` · Local result: **passed** · Overall: **partial**.

Six supported Linux ACT jobs are separate from PR/provider, native-platform and physical-device gates.

| Job | Status | Evidence |
| --- | --- | --- |
| build | passed | [20261115T174023Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174023Z-build.json) |
| coverage | passed | [20261115T174101Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174101Z-coverage.json) |
| lint | passed | [20261115T173943Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T173943Z-lint.json) |
| snapshot | passed | [20261115T174150Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174150Z-snapshot.json) |
| docs | passed | [20261115T174525Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174525Z-docs.json) |
| candidate | passed | [20261115T174541Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174541Z-candidate.json) |

## Retained runs

Raw outcomes, counts, commands and source/client/runner/workflow/configuration hashes are retained in report.json.

| Run | Recorded / raw | Integrity / clean | Evidence |
| --- | --- | --- | --- |
| 20261115T173943Z-lint | passed / passed | verified / True | [20261115T173943Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T173943Z-lint.json) · [20261115T173943Z-lint.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T173943Z-lint.log) |
| 20261115T174023Z-build | passed / passed | verified / True | [20261115T174023Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174023Z-build.json) · [20261115T174023Z-build.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174023Z-build.log) |
| 20261115T174101Z-coverage | passed / passed | verified / True | [20261115T174101Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174101Z-coverage.json) · [20261115T174101Z-coverage.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174101Z-coverage.log) |
| 20261115T174150Z-snapshot | passed / passed | verified / True | [20261115T174150Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174150Z-snapshot.json) · [20261115T174150Z-snapshot.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174150Z-snapshot.log) |
| 20261115T174525Z-docs | passed / passed | verified / True | [20261115T174525Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174525Z-docs.json) · [20261115T174525Z-docs.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174525Z-docs.log) |
| 20261115T174541Z-candidate | passed / passed | verified / True | [20261115T174541Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174541Z-candidate.json) · [20261115T174541Z-candidate.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261115T174541Z-candidate.log) |

## Actionable failure groups

No verified failed-run findings. This does not complete unrun or unavailable checks.
## Evidence errors

None.

## Separate gates

PR static runs: unrun.

- dependency-review (real PR/provider): **unrun**.
- native Windows 2025: **unrun**.
- native macOS 15: **unrun**.
- Linux arm64 runtime: **unrun**.
- actual Steam Deck/Flatpak/Gamescope/controller/audio: **unrun**.
- provider viewer reception: **unrun**.
- hosted GitHub CI/reviews/artifact delivery: **unrun**.

- Only verified adjacent logs are parsed. Counts describe observed events/summaries, not unlogged tests.
- Missing legacy provenance hashes remain null; current files do not reconstruct historical binaries/configuration.
- Passed-job error text may be an expected negative control: it remains diagnostic, not a failure finding.
- Private logs/reports require human review before sharing. No issue, provider action or publication is performed.
