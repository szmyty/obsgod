#!/usr/bin/env python3
"""Read-only ZIP validation plus isolated executable/backend/HTTP smoke; no OBS."""
import argparse,hashlib,http.client,importlib.util,json,os,subprocess,sys,tempfile,threading
from pathlib import Path
ROOT=Path('/workspace/obsgod')
spec=importlib.util.spec_from_file_location('audit',ROOT/'scripts/release-audit.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
root,files=audit.archive_files(args.archive.read_bytes(),'zip')
assert root=='obsgod' and set(files)==audit.STANDARD_PLUGIN_FILES
manifest=json.loads(files['manifest.json']);audit.verify_manifest(files,manifest)
assert manifest['dirty'] is False
sdkroot,sdk=audit.archive_files(files['source/decky-api/SOURCE.tar.gz'],'tar')
assert sdkroot=='decky-api' and {name:audit.sha(data) for name,data in sdk.items()}==audit.SDK_SOURCE
with tempfile.TemporaryDirectory(prefix='obsgod-real-package-smoke-') as td:
    work=Path(td);installed=work/'obsgod';installed.mkdir()
    for name,data in files.items():
        target=installed/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        target.chmod(0o755 if name.startswith('bin/') else 0o644)
    tools=work/'tools';tools.mkdir();boundary=work/'external-commands.log'
    for name in ('flatpak','obs','obs-studio'):
        shim=tools/name;shim.write_text('#!/bin/sh\nprintf "%s %s\\n" "'+name+'" "$*" >> "$OBSGOD_SMOKE_BOUNDARY_LOG"\nexit 1\n');shim.chmod(0o700)
    runtime=work/'runtime';runtime.mkdir(mode=0o700)
    env={'PATH':str(tools)+':/usr/bin:/bin','HOME':str(work/'home'),'XDG_CONFIG_HOME':str(work/'config'),'XDG_STATE_HOME':str(work/'state'),'XDG_DATA_HOME':str(work/'data'),'XDG_CACHE_HOME':str(work/'cache'),'XDG_RUNTIME_DIR':str(runtime),'OBSGOD_SMOKE_BOUNDARY_LOG':str(boundary),'PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8'}
    version_cmd=[str(installed/'bin/obsgod'),'--version']
    version=subprocess.check_output(version_cmd,env=env,text=True).strip();assert manifest['revision'] in version
    status_cmd=[str(installed/'bin/obsgod'),'deck','status']
    status_process=subprocess.run(status_cmd,env=env,capture_output=True,text=True,timeout=10)
    status=json.loads(status_process.stdout);assert status.get('configured') is False
    probe=r'''
import sys,json,http.client,threading
sys.path.insert(0,sys.argv[1])
import main,setup,bridge
assert setup.PLUGIN_BUNDLE
assert 'install' not in sys.modules and 'decky' not in sys.modules
plugin=main.Plugin();assert plugin is not None
server=setup.SetupServer();thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
checks=[]
try:
    connection=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=10)
    connection.request('GET','/api/status');response=connection.getresponse();response.read();assert response.status==403;checks.append('unauthenticated status rejected')
    headers={'Authorization':'Bearer '+server.token,'Content-Type':'application/json'}
    connection.request('GET','/api/status',headers=headers);response=connection.getresponse();data=json.loads(response.read());assert response.status==200 and data['install_channel']=='decky' and data['configured'] is False and data['plugin_zip'] is None;checks.append('authenticated status used actual bundled CLI')
    for action in ('dependencies','install-plugin'):
        connection.request('POST','/api/action',body=json.dumps({'action':action}),headers=headers);response=connection.getresponse();reply=json.loads(response.read());assert response.status==200 and reply['ok'] is False and not reply['running'];checks.append(action+' redirected without legacy installer')
    connection.request('POST','/api/action',body=json.dumps({'action':'start'}),headers=headers);response=connection.getresponse();response.read();assert response.status==400;checks.append('browser cannot start broadcasting')
    connection.request('GET','/setup.js');response=connection.getresponse();assert response.status==200 and b'renderInstallChannel' in response.read();checks.append('bundled static assets served')
    connection.close()
finally:
    server.shutdown();thread.join();server.server_close()
print(json.dumps({'isolated_backend_import':'passed','legacy_installer_imported':False,'http_checks':checks}))
'''
    probe_cmd=[sys.executable,'-I','-c',probe,str(installed)]
    probe_process=subprocess.run(probe_cmd,env=env,capture_output=True,text=True,timeout=20,check=True)
    http_result=json.loads(probe_process.stdout)
    commands=boundary.read_text().splitlines() if boundary.exists() else []
    assert not any(line.startswith(('flatpak run','obs ','obs-studio ')) for line in commands),commands
    native=json.loads(files['build/capture-build.json']);assert native['sha256']==hashlib.sha256(files['bin/libgstobsgodcapture.so']).hexdigest()
    receipt={'revision':manifest['revision'],'archive':str(args.archive),'archive_sha256':hashlib.sha256(args.archive.read_bytes()).hexdigest(),'platform':'Linux x86_64 cloud; synthetic private HOME, no session bus','commands':[version_cmd,status_cmd,[sys.executable,'-I','-c','[isolated import/authenticated HTTP probe recorded in actual-package-smoke.py]',str(installed)]],'payload_inventory':'passed','manifest_hashes':'passed','sdk_original_source_hashes':'passed','go_version_execution':version,'status_exit_code':status_process.returncode,'status_configured':status['configured'],'status_state':status.get('state'),'backend_http_smoke':http_result,'external_boundary_commands':commands,'no_automatic_obs_spawn':'passed','native_receipt_matches':'passed','device_installation':'unrun','obs_startup_streaming':'unrun','network_broadcast':'not attempted'}
    args.output.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
