import hashlib
import importlib.util
import json
import os
from pathlib import Path
import pwd
import subprocess
import tempfile

root = Path('/workspace/obsgod')
spec = importlib.util.spec_from_file_location('deckystorage', root / 'steamdeck/decky/storage.py')
storage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(storage)
binary = Path('/workspace/.obsgod-tools/decky-foundation-evidence/source-7e539ca/packaged-obsgod')
inputs = ['internal/deck/config.go', 'internal/deck/storage_map_linux.go',
          'internal/deck/storage_map_other.go', 'steamdeck/decky/storage.py']
with tempfile.TemporaryDirectory(prefix='decky-storage-cross-language-') as temporary:
    fixture = Path(temporary)
    home, plugin = fixture / 'home', fixture / 'bundle'
    home.mkdir(mode=0o700)
    plugin.mkdir(mode=0o700)
    supplied = {'DECKY_USER_HOME': str(home), 'DECKY_USER': pwd.getpwuid(os.getuid()).pw_name}
    for key, name in [('DECKY_PLUGIN_SETTINGS_DIR', 'settings'),
                      ('DECKY_PLUGIN_RUNTIME_DIR', 'persistent'),
                      ('DECKY_PLUGIN_LOG_DIR', 'logs')]:
        path = fixture / name
        path.mkdir(mode=0o700)
        supplied[key] = str(path)
    env = {'HOME': str(home), 'PATH': os.environ['PATH'],
           'XDG_CONFIG_HOME': str(fixture / 'shared-config'),
           'XDG_STATE_HOME': str(fixture / 'shared-state'),
           'XDG_DATA_HOME': str(fixture / 'real-flatpak-user-data')}
    child = storage.child_environment(plugin, supplied, env)
    valid = subprocess.run([str(binary), 'deck', 'status'], env=child, text=True, capture_output=True, timeout=15)
    output = json.loads(valid.stdout)
    assert valid.returncode == 0 and 'storage map' not in output.get('message', '').lower()
    assert not output.get('stream', {}).get('active', False)
    map_path = Path(child[storage.MAP_ENV])
    mapping = json.loads(map_path.read_text())
    mapping['shared']['state'] = str(fixture / 'second-controller')
    map_path.write_text(json.dumps(mapping))
    map_path.chmod(0o600)
    invalid = subprocess.run([str(binary), 'deck', 'status'], env=child, text=True, capture_output=True, timeout=15)
    assert invalid.returncode != 0 and 'storage map' in (invalid.stdout + invalid.stderr).lower()
    assert not (fixture / 'second-controller').exists()
    record = {'schema': 'decky-storage-cross-language-check/v1',
              'python_map_consumed_by_go': True, 'valid_map_status': output.get('state'),
              'changed_store_rejected': True, 'second_controller_created': False,
              'uid': os.getuid(), 'ephemeral_runtime_not_replaced': child.get('XDG_RUNTIME_DIR') != supplied['DECKY_PLUGIN_RUNTIME_DIR'],
              'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
              'source_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in inputs},
              'scope': 'Actual packaged 7e539ca interoperability; not physical Deck qualification'}
    Path('/workspace/.obsgod-tools/decky-foundation-evidence/source-7e539ca/cross-language.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))
