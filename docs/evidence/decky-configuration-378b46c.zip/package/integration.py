#!/usr/bin/env python3
"""Actual packaged Decky Python -> packaged Go, private offline configuration.

Synthetic secrets remain in memory/private fixture files and never enter argv or
receipts. OBS/Flatpak/desktop process boundaries are refused and counted. This
does not qualify real Decky transport, SteamOS, OBS launch, audio or a provider.
"""
import argparse
import asyncio
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import platform
import pwd
import secrets
import socket
import stat
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from unittest.mock import patch


SENSITIVE = set()
CHECKS = []
SPAWNS = []
CURRENT_STEP = "prepare"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify(name, condition):
    global CURRENT_STEP
    CURRENT_STEP = name
    if not condition:
        raise AssertionError(name)
    CHECKS.append({"name": name, "status": "passed"})


def no_private(value):
    encoded = json.dumps(value, sort_keys=True)
    verify("public response contains no observed credential", not any(item and item in encoded for item in SENSITIVE))
    return value


def credentials(home):
    path = home / ".config/obsgod/secrets.json"
    value = json.loads(path.read_text())
    verify("credentials are a private regular file", stat.S_ISREG(path.lstat().st_mode) and stat.S_IMODE(path.stat().st_mode) == 0o600)
    for field in ("stream_key", "obs_password"):
        verify("private credential exists", isinstance(value.get(field), str) and bool(value[field]))
        SENSITIVE.add(value[field])
    verify("stream key differs from managed password", value["stream_key"] != value["obs_password"])
    return value


async def exercise(plugin_root, fixture):
    home = fixture / "home"
    home.mkdir(mode=0o700)
    roots = {}
    for name in ("settings", "runtime", "logs"):
        path = home / ("decky-" + name)
        path.mkdir(mode=0o700)
        roots[name] = path
    session = home / "session"
    session.mkdir(mode=0o700)
    barriers = fixture / "barriers"
    barriers.mkdir(mode=0o700)
    boundary_log = fixture / "boundary.log"
    for command in ("flatpak", "obs", "obs64", "obs-studio", "xdg-open", "dbus-send", "busctl", "gdbus", "pkill", "killall"):
        path = barriers / command
        path.write_text("#!" + sys.executable + "\nimport pathlib,sys\nwith pathlib.Path(" + repr(str(boundary_log)) + ").open('a') as f:f.write(" + repr(command + "\n") + ")\nsys.exit(97)\n")
        path.chmod(0o700)
    ordinary = home / ".var/app/com.obsproject.Studio/config/obs-studio/ordinary-fixture.ini"
    ordinary.parent.mkdir(parents=True, mode=0o700)
    ordinary.write_text("ordinary OBS stays untouched\n")
    original_ordinary = ordinary.read_bytes()
    environment = dict(os.environ)
    for name in ("OBSGOD_DECKY_STORAGE_MAP", "OBSGOD_DECKY_RUNTIME_DIR", "OBSGOD_DECKY_LOG_DIR", "FLATPAK_USER_DIR", "FLATPAK_SYSTEM_DIR"):
        environment.pop(name, None)
    environment.update(HOME=str(home), DECKY_USER_HOME=str(home), DECKY_USER=pwd.getpwuid(os.getuid()).pw_name,
        DECKY_PLUGIN_DIR=str(plugin_root), DECKY_PLUGIN_SETTINGS_DIR=str(roots["settings"]),
        DECKY_PLUGIN_RUNTIME_DIR=str(roots["runtime"]), DECKY_PLUGIN_LOG_DIR=str(roots["logs"]),
        XDG_CONFIG_HOME=str(home / ".config"), XDG_STATE_HOME=str(home / ".local/state"),
        XDG_DATA_HOME=str(home / ".local/share"), XDG_CACHE_HOME=str(home / ".cache"),
        XDG_RUNTIME_DIR=str(session), DBUS_SESSION_BUS_ADDRESS="unix:path=" + str(session / "bus"),
        PATH=str(barriers) + os.pathsep + os.environ.get("PATH", ""))
    spec = importlib.util.spec_from_file_location("actual_packaged_configuration_backend", plugin_root / "main.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    real_spawn = asyncio.create_subprocess_exec

    async def spawn(*args, **kwargs):
        verify("adapter invokes only packaged Go with a fixed deck action", len(args) == 3 and args[0] == str(plugin_root / "bin/obsgod") and args[1] == "deck")
        verify("credentials never enter process argv", not any(secret and secret in json.dumps(args) for secret in SENSITIVE))
        SPAWNS.append({"action": args[2], "input": "private JSON stdin" if kwargs.get("stdin") == asyncio.subprocess.PIPE else "none"})
        return await real_spawn(*args, **kwargs)

    with patch.dict(os.environ, environment, clear=True), patch.object(module.asyncio, "create_subprocess_exec", side_effect=spawn):
        plugin = module.Plugin()
        await plugin._main()
        first = no_private(await plugin.configuration_status())
        verify("fresh packaged configuration is editable without OBS dependencies", first["ok"] and not first["configured"] and first["can_configure"] and first["output_known"])
        key_a, key_b, key_c = (secrets.token_hex(24) for _ in range(3))
        SENSITIVE.update((key_a, key_b, key_c))
        kick = "rtmps://synthetic-kick.global-contribute.live-video.net:443/app"
        twitch = "rtmps://ingest.global-contribute.live-video.net/app"
        saved = await plugin.configure_destination({"server": kick, "stream_key": key_a, "bitrate": 4500,
            "fps": 30, "encoder": "vaapi", "width": 1280, "height": 720, "capture_mode": "game", "microphone": False})
        initial_secret = credentials(home)
        no_private(saved)
        verify("first Kick save crosses actual Python and Go", saved["action_result"]["ok"] and saved["configured"] and saved["key_configured"] and initial_secret["stream_key"] == key_a)
        verify("native readback excludes key and password fields", "stream_key" not in saved["settings"] and "password" not in saved["connection"])
        config_path = home / ".config/obsgod/deck.json"
        seeded = json.loads(config_path.read_text())
        seeded.update(idle_style="placeholder", idle_text="Preserve the existing idle scene message", microphone=True, stream_key="")
        # Seed supported advanced preferences via the existing real CLI. No
        # direct file edit can bypass its destination/settings binding.
        seed_result = subprocess.run([str(plugin_root / "bin/obsgod"), "deck", "configure"],
            input=json.dumps(seeded).encode(), stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            env=plugin._child_environment(), timeout=12)
        seed_value = no_private(json.loads(seed_result.stdout))
        verify("legacy Configure seeds advanced preferences without resetting credentials", seed_result.returncode == 0 and seed_value["ok"] and credentials(home)["obs_password"] == initial_secret["obs_password"])
        patched = await plugin.configure_destination({"bitrate": 5200, "stream_key": ""})
        patched_secret = credentials(home)
        no_private(patched)
        configured = json.loads(config_path.read_text())
        verify("blank key retains only the same destination binding", patched["action_result"]["ok"] and patched_secret["stream_key"] == key_a and configured["server"] == kick)
        verify("quality merge preserves advanced and microphone preferences", configured["bitrate"] == 5200 and configured["idle_style"] == "placeholder" and configured["idle_text"] == seeded["idle_text"] and configured["microphone"] is True)
        before = (config_path.read_bytes(), (home / ".config/obsgod/secrets.json").read_bytes())
        refused = no_private(await plugin.configure_destination({"server": twitch, "stream_key": ""}))
        verify("changed server cannot reuse a blank stored key", not refused["action_result"]["ok"] and before == (config_path.read_bytes(), (home / ".config/obsgod/secrets.json").read_bytes()))
        replacement = await plugin.configure_destination({"server": twitch, "stream_key": key_b})
        replaced_secret = credentials(home)
        no_private(replacement)
        verify("new destination accepts its explicit key", replacement["action_result"]["ok"] and replaced_secret["stream_key"] == key_b and replacement["settings"]["server"] == twitch)
        refused_account = no_private(await plugin.configure_destination({"replace_key": True, "stream_key": ""}))
        verify("same-server account replacement requires an explicit new key", not refused_account["action_result"]["ok"] and credentials(home)["stream_key"] == key_b)
        account = await plugin.configure_destination({"replace_key": True, "stream_key": key_c})
        account_secret = credentials(home)
        no_private(account)
        verify("same-server replacement saves its explicit key", account["action_result"]["ok"] and account_secret["stream_key"] == key_c)
        password = secrets.token_urlsafe(24)
        SENSITIVE.add(password)
        changed = await plugin.change_control_password({"password": password, "confirm": True})
        changed_secret = credentials(home)
        no_private(changed)
        ws_path = home / ".var/app/com.obsproject.Studio/config/obsgod/obs-studio/plugin_config/obs-websocket/config.json"
        websocket = json.loads(ws_path.read_text())
        verify("custom password synchronizes private OBS and controller stores", changed["action_result"]["ok"] and changed_secret["obs_password"] == password and websocket["server_password"] == password and websocket["auth_required"] is True and websocket["server_enabled"] is True and websocket["server_port"] == 4457)
        verify("password update preserves destination key", changed_secret["stream_key"] == key_c)
        generated = await plugin.change_control_password({"generate": True, "confirm": True})
        generated_secret = credentials(home)
        no_private(generated)
        verify("automatic password generation remains private and distinct", generated["action_result"]["ok"] and generated_secret["obs_password"] != password and generated_secret["stream_key"] == key_c and len(generated_secret["obs_password"]) >= 12)
        verify("managed WebSocket settings remain private", stat.S_IMODE(ws_path.stat().st_mode) == 0o600 and json.loads(ws_path.read_text())["server_password"] == generated_secret["obs_password"])
        tested = no_private(await plugin.test_control_connection())
        verify("read-only connection test reports closed listener without launch", tested["action_result"]["ok"] is False and tested["connection"]["connected"] is False and tested["connection"]["process"] == "absent")
        closed = no_private(await plugin.close_managed_obs())
        verify("explicit close is safe when managed OBS is already absent", closed["action_result"]["ok"] and closed["connection"]["process"] == "absent")
        observed = no_private(await plugin.status())
        verify("all operations leave output positively absent", observed["output_known"] is True and observed["process"] == "absent" and not observed["stream"]["active"])
        verify("ordinary OBS preferences remain byte-identical", ordinary.read_bytes() == original_ordinary)
        verify("no OBS, Flatpak, desktop or process-control command was invoked", not boundary_log.exists())
        verify("no broadcast, recording, OBS-open or dependency action reached packaged Go", all(row["action"] in {"configuration", "configure-fields", "change-obs-password", "test-connection", "restart", "status"} for row in SPAWNS))
        verify("no private payload remains on the Python controller", plugin._control_payload is None)
        no_private(plugin._last_action)
        verify("advanced preferences survive all native changes", json.loads(config_path.read_text())["idle_text"] == seeded["idle_text"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("plugin_zip", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--revision", required=True)
    args = parser.parse_args()
    os.umask(0o077)
    receipt = {"schema_version": 1, "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "failed", "platform": platform.platform(), "python": sys.version, "uid": os.getuid(),
        "command": ["python3", str(Path(__file__).resolve()), str(args.plugin_zip.resolve()), "--revision", args.revision, "--output", str(args.output.resolve())],
        "harness_sha256": digest(Path(__file__).read_bytes()), "checks": CHECKS, "spawns": SPAWNS,
        "limitations": ["Synthetic private account home/XDG/Decky paths; not a real loader transport", "No SteamOS, OBS launch, Flatpak transaction, controller, audio/video or provider viewer qualification", "Offline authenticated-listener test is expected to report a closed listener; no live authentication proof"]}
    started = time.monotonic()
    try:
        verify("execution is unprivileged", os.getuid() == os.geteuid() and os.geteuid() != 0)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.settimeout(0.3)
            verify("the real managed control port is unused", probe.connect_ex(("127.0.0.1", 4457)) != 0)
        archive_bytes = args.plugin_zip.read_bytes()
        receipt["artifact"] = {"path": str(args.plugin_zip.resolve()), "sha256": digest(archive_bytes), "bytes": len(archive_bytes)}
        with tempfile.TemporaryDirectory(prefix="packaged-config-", dir=str(args.output.parent)) as temporary:
            fixture = Path(temporary)
            with zipfile.ZipFile(args.plugin_zip) as archive:
                names = archive.namelist()
                verify("package contains only unique safe plugin paths", len(names) == len(set(names)) and all(name.startswith("obsgod/") and not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts for name in names))
                for member in archive.infolist():
                    verify("archive entries are ordinary files", stat.S_ISREG(member.external_attr >> 16))
                    target = fixture / member.filename
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(archive.read(member))
                    target.chmod(0o700 if member.filename.startswith("obsgod/bin/") else 0o600)
            plugin_root = fixture / "obsgod"
            manifest = json.loads((plugin_root / "manifest.json").read_text())
            receipt["source"] = {name: manifest.get(name) for name in ("revision", "dirty", "version", "platform", "source_tools")}
            verify("package declares the requested clean source", manifest["revision"] == args.revision and manifest["dirty"] is False)
            verify("all manifest payload hashes match shipped bytes", all(digest((plugin_root / name).read_bytes()) == value for name, value in manifest["files"].items()))
            receipt["payload_hashes"] = {name: digest((plugin_root / name).read_bytes()) for name in ("main.py", "storage.py", "dependency_setup.py", "bin/obsgod")}
            asyncio.run(exercise(plugin_root, fixture))
        receipt["status"] = "passed"
    except Exception as error:
        receipt["failure"] = {"step": CURRENT_STEP, "type": type(error).__name__}
    receipt["seconds"] = round(time.monotonic() - started, 3)
    encoded = json.dumps(receipt, indent=2, sort_keys=True)
    if any(secret and secret in encoded for secret in SENSITIVE):
        raise AssertionError("Private fixture data reached the evidence boundary")
    args.output.write_text(encoded + "\n")
    print("Packaged Python-to-Go configuration integration:", receipt["status"], "checks:", len(CHECKS))
    if receipt["status"] != "passed":
        print("Failed safe step:", CURRENT_STEP)
    return 0 if receipt["status"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())
