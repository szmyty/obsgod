# Current GitHub Actions audit

Observed 2026-11-14T20:08:03Z. Read-only audit of default/master and current PR73/74/75/90 heads.

**Hosted:** 42 failed workflow runs, 69 jobs, zero executed steps. 64 jobs carry the exact billing-lock annotation; five dependency-review jobs are correctly skipped on push. No currently executed nonbilling hosted failure was found.

**New fixable local finding:** pinned staticcheck v0.8.2 fails `internal/deck/storage_map_linux.go:39:26` with ST1005 because the error begins `Decky storage map…`. Cause is present in immutable source00a5593; no source edited by this audit. Root should create a focused issue and repair lowercase wording.

Direct gofmt/vet, funding metadata and docs build/check/tests passed. These are diagnostic commands, not final qualification: #79 source work is concurrent.

**Separate capability gate:** fork dependency-comparison403 is not a billing or source-code pass and remains tracked under #46/#85/migration.

Documentation preview was last triggered at PR74 because its path filters do not match later code-only heads. The dynamic Copilot workflow latest run is a historical June2026 success, not an active failure.

See audit.json for every job URL/source/classification and current-jobs.json/current-annotations.json for raw public API evidence.
