# Local CI report

Source: `378b46cb8c4a9281f9d6890b2e13b223650626d5` · Local result: **passed** · Overall: **partial**.

Six supported Linux ACT jobs are separate from PR/provider, native-platform and physical-device gates.

| Job | Status | Evidence |
| --- | --- | --- |
| build | passed | [20261114T205204Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205204Z-build.json) |
| coverage | passed | [20261114T205253Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205253Z-coverage.json) |
| lint | passed | [20261114T205121Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205121Z-lint.json) |
| snapshot | passed | [20261114T205347Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205347Z-snapshot.json) |
| docs | passed | [20261114T205530Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205530Z-docs.json) |
| candidate | passed | [20261114T210402Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T210402Z-candidate.json) |

## Retained runs

Raw outcomes, counts, commands and source/client/runner/workflow/configuration hashes are retained in report.json.

| Run | Recorded / raw | Integrity / clean | Evidence |
| --- | --- | --- | --- |
| 20261114T205121Z-lint | passed / passed | verified / True | [20261114T205121Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205121Z-lint.json) · [20261114T205121Z-lint.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205121Z-lint.log) |
| 20261114T205204Z-build | passed / passed | verified / True | [20261114T205204Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205204Z-build.json) · [20261114T205204Z-build.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205204Z-build.log) |
| 20261114T205253Z-coverage | passed / passed | verified / True | [20261114T205253Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205253Z-coverage.json) · [20261114T205253Z-coverage.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205253Z-coverage.log) |
| 20261114T205347Z-snapshot | passed / passed | verified / True | [20261114T205347Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205347Z-snapshot.json) · [20261114T205347Z-snapshot.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205347Z-snapshot.log) |
| 20261114T205530Z-docs | passed / passed | verified / True | [20261114T205530Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205530Z-docs.json) · [20261114T205530Z-docs.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205530Z-docs.log) |
| 20261114T205540Z-candidate | failed / failed | verified / True | [20261114T205540Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205540Z-candidate.json) · [20261114T205540Z-candidate.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205540Z-candidate.log) |
| 20261114T210402Z-candidate | passed / passed | verified / True | [20261114T210402Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T210402Z-candidate.json) · [20261114T210402Z-candidate.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T210402Z-candidate.log) |

## Actionable failure groups

### candidate: Main Native audio and app-filtered capture checks

Classification: **environment_storage** · Raw execution: **failed** · superseded_by_later_pass.

Reproduction (review captured context/placeholders before running):

```sh
python3 scripts/local-ci.py candidate --state /workspace/.obsgod-tools/actions-current-audit/local/act-state --act /workspace/.obsgod-tools/pkg/bin/act
```

1. Confirm a clean checkout of 378b46cb8c4a9281f9d6890b2e13b223650626d5.
2. Inspect free disk; preserve evidence and select only disposable cache cleanup, then rerun this exact job.
3. Compare new evidence without overwriting these receipts; review private logs before sharing.

Evidence: [20261114T205540Z-candidate.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T205540Z-candidate.log:1141)

## Evidence errors

None.

## Separate gates

PR static runs: unrun.

- dependency-review (real PR/provider): **unrun**.
- native Windows 2025: **unrun**.
- native macOS 15: **unrun**.
- Linux arm64 runtime: **unrun**.
- actual Steam Deck/Flatpak/Gamescope/controller/audio: **unrun**.
- provider viewer reception: **unrun**.
- hosted GitHub CI/reviews/artifact delivery: **unrun**.

- Only verified adjacent logs are parsed. Counts describe observed events/summaries, not unlogged tests.
- Missing legacy provenance hashes remain null; current files do not reconstruct historical binaries/configuration.
- Passed-job error text may be an expected negative control: it remains diagnostic, not a failure finding.
- Private logs/reports require human review before sharing. No issue, provider action or publication is performed.
