Test-only dependency fixture repair

Only `steamdeck/tests/test_dependency_setup.py` changed. The fake Flatpak now waits for an explicit release marker; the test verifies the original child completion marker and polls the actual existing setup flock with a four-second bound. The real worker keeps its three-second budget. No product source or expected recovery state was changed.

Before and after parent loss, status must remain running with install disabled. Retry must retain the same operation ID without another mutation. After real lease release, the original interrupted, compatible OBS and can-install assertions remain, with exactly one mutation verified again.

Checks: host UID1000 repeated case12/12; existing ACT image UID1000 repeated case12/12; full dependency module18passed/1root-only skip; Python3.9 grammar and diff whitespace passed. Exact commands, source/log hashes and the original failed candidate log binding are in adjacent JSON receipts. Independent read-only final diff review passed. A new complete source-bound matrix remains root-owned and unrun.
