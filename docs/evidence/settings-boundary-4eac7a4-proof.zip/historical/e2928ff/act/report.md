# Local CI report

Source: `e2928ffea50eaf9988be30c47d2c471c8653434e` · Local result: **failed** · Overall: **failed**.

Six supported Linux ACT jobs are separate from PR/provider, native-platform and physical-device gates.

| Job | Status | Evidence |
| --- | --- | --- |
| build | passed | [20261118T193642Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193642Z-build.json) |
| coverage | passed | [20261118T193719Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193719Z-coverage.json) |
| lint | passed | [20261118T193603Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193603Z-lint.json) |
| snapshot | passed | [20261118T193807Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193807Z-snapshot.json) |
| docs | passed | [20261118T194147Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T194147Z-docs.json) |
| candidate | failed | [20261118T194207Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T194207Z-candidate.json) |

## Retained runs

Raw outcomes, counts, commands and source/client/runner/workflow/configuration hashes are retained in report.json.

| Run | Recorded / raw | Integrity / clean | Evidence |
| --- | --- | --- | --- |
| 20261118T193603Z-lint | passed / passed | verified / True | [20261118T193603Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193603Z-lint.json) · [20261118T193603Z-lint.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193603Z-lint.log) |
| 20261118T193642Z-build | passed / passed | verified / True | [20261118T193642Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193642Z-build.json) · [20261118T193642Z-build.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193642Z-build.log) |
| 20261118T193719Z-coverage | passed / passed | verified / True | [20261118T193719Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193719Z-coverage.json) · [20261118T193719Z-coverage.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193719Z-coverage.log) |
| 20261118T193807Z-snapshot | passed / passed | verified / True | [20261118T193807Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193807Z-snapshot.json) · [20261118T193807Z-snapshot.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T193807Z-snapshot.log) |
| 20261118T194147Z-docs | passed / passed | verified / True | [20261118T194147Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T194147Z-docs.json) · [20261118T194147Z-docs.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T194147Z-docs.log) |
| 20261118T194207Z-candidate | failed / failed | verified / True | [20261118T194207Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T194207Z-candidate.json) · [20261118T194207Z-candidate.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T194207Z-candidate.log) |

## Actionable failure groups

### candidate: Main Installer, backend and panel checks

Classification: **workflow_failure** · Raw execution: **failed** · open.

Reproduction (review captured context/placeholders before running):

```sh
python3 scripts/local-ci.py candidate --state /workspace/.obsgod-tools/actions-current-audit/local/act-state --act /workspace/.obsgod-tools/pkg/bin/act
```

1. Confirm a clean checkout of e2928ffea50eaf9988be30c47d2c471c8653434e.
2. Reproduce the captured job from the exact clean revision, inspect its first failing step, repair the demonstrated source/fixture/environment cause, and retain the new receipt.
3. Compare new evidence without overwriting these receipts; review private logs before sharing.

Evidence: [20261118T194207Z-candidate.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T194207Z-candidate.log:923)

## Evidence errors

None.

## Separate gates

PR static runs: unrun.

- dependency-review (real PR/provider): **unrun**.
- native Windows 2025: **unrun**.
- native macOS 15: **unrun**.
- Linux arm64 runtime: **unrun**.
- actual Steam Deck/Flatpak/Gamescope/controller/audio: **unrun**.
- provider viewer reception: **unrun**.
- hosted GitHub CI/reviews/artifact delivery: **unrun**.

- Only verified adjacent logs are parsed. Counts describe observed events/summaries, not unlogged tests.
- Missing legacy provenance hashes remain null; current files do not reconstruct historical binaries/configuration.
- Passed-job error text may be an expected negative control: it remains diagnostic, not a failure finding.
- Private logs/reports require human review before sharing. No issue, provider action or publication is performed.
