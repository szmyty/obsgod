# Local CI report

Source: `4eac7a469285cbafad5dc5a7ea07205374293dfd` · Local result: **failed** · Overall: **failed**.

Six supported Linux ACT jobs are separate from PR/provider, native-platform and physical-device gates.

| Job | Status | Evidence |
| --- | --- | --- |
| build | passed | [20261118T195514Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195514Z-build.json) |
| coverage | passed | [20261118T195549Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195549Z-coverage.json) |
| lint | passed | [20261118T195426Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195426Z-lint.json) |
| snapshot | passed | [20261118T195623Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195623Z-snapshot.json) |
| docs | passed | [20261118T195747Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195747Z-docs.json) |
| candidate | failed | [20261118T195801Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195801Z-candidate.json) |

## Retained runs

Raw outcomes, counts, commands and source/client/runner/workflow/configuration hashes are retained in report.json.

| Run | Recorded / raw | Integrity / clean | Evidence |
| --- | --- | --- | --- |
| 20261118T195426Z-lint | passed / passed | verified / True | [20261118T195426Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195426Z-lint.json) · [20261118T195426Z-lint.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195426Z-lint.log) |
| 20261118T195514Z-build | passed / passed | verified / True | [20261118T195514Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195514Z-build.json) · [20261118T195514Z-build.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195514Z-build.log) |
| 20261118T195549Z-coverage | passed / passed | verified / True | [20261118T195549Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195549Z-coverage.json) · [20261118T195549Z-coverage.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195549Z-coverage.log) |
| 20261118T195623Z-snapshot | passed / passed | verified / True | [20261118T195623Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195623Z-snapshot.json) · [20261118T195623Z-snapshot.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195623Z-snapshot.log) |
| 20261118T195747Z-docs | passed / passed | verified / True | [20261118T195747Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195747Z-docs.json) · [20261118T195747Z-docs.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195747Z-docs.log) |
| 20261118T195801Z-candidate | failed / failed | verified / True | [20261118T195801Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195801Z-candidate.json) · [20261118T195801Z-candidate.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195801Z-candidate.log) |

## Actionable failure groups

### candidate: Main Go protocol, race, static and vulnerability checks

Classification: **workflow_failure** · Raw execution: **failed** · open.

Reproduction (review captured context/placeholders before running):

```sh
python3 scripts/local-ci.py candidate --state /workspace/.obsgod-tools/actions-current-audit/local/act-state --act /workspace/.obsgod-tools/pkg/bin/act
```

1. Confirm a clean checkout of 4eac7a469285cbafad5dc5a7ea07205374293dfd.
2. Reproduce the captured job from the exact clean revision, inspect its first failing step, repair the demonstrated source/fixture/environment cause, and retain the new receipt.
3. Compare new evidence without overwriting these receipts; review private logs before sharing.

Evidence: [20261118T195801Z-candidate.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261118T195801Z-candidate.log:594)

## Evidence errors

None.

## Separate gates

PR static runs: unrun.

- dependency-review (real PR/provider): **unrun**.
- native Windows 2025: **unrun**.
- native macOS 15: **unrun**.
- Linux arm64 runtime: **unrun**.
- actual Steam Deck/Flatpak/Gamescope/controller/audio: **unrun**.
- provider viewer reception: **unrun**.
- hosted GitHub CI/reviews/artifact delivery: **unrun**.

- Only verified adjacent logs are parsed. Counts describe observed events/summaries, not unlogged tests.
- Missing legacy provenance hashes remain null; current files do not reconstruct historical binaries/configuration.
- Passed-job error text may be an expected negative control: it remains diagnostic, not a failure finding.
- Private logs/reports require human review before sharing. No issue, provider action or publication is performed.
