"""Disposable mocked lifecycle audit proofs. Never invokes OBS/Decky/Flatpak/network."""
import asyncio, contextlib, fcntl, importlib.util, io, json, os
from pathlib import Path
import shutil, sys, tempfile
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
sys.dont_write_bytecode = True
SOURCE=Path('/workspace/obsgod/steamdeck')
def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
backend=load('audit_backend',SOURCE/'decky/main.py')
uninstall=load('audit_uninstall',SOURCE/'uninstall.py')
installer=load('audit_install',SOURCE/'install.py')
IDLE={'ok':True,'state':'stopped','output_known':True,'stream':{'active':False},'recording':False,'process':'absent','media':{'known':True,'replay_active':False}}
results={}

async def teardown_reader():
    p=backend.Plugin(); entered=asyncio.Event(); finish=asyncio.Event(); calls=[]
    async def run(action,payload=None):
        calls.append(action)
        if action=='configuration':
            entered.set(); await finish.wait()
        return dict(IDLE)
    with patch.object(p,'_run',side_effect=run):
        request=asyncio.create_task(p.configuration_status()); await entered.wait()
        result=await p._unload()
        results['teardown_config_reader']={'unload_returned':True,'unload_output_known':result['output_known'],'pending_owned_configuration_tasks':sum(not t.done() for t in p._configuration_tasks),'request_still_pending':not request.done(),'actions_before_ack':list(calls)}
        finish.set(); await request
asyncio.run(teardown_reader())

with tempfile.TemporaryDirectory(prefix='obsgod-audit-lifecycle-') as tmp:
    home=Path(tmp)/'home'; home.mkdir(mode=0o700)
    base=home/'data/obsgod'; state=home/'state/obsgod'
    for p in [base,state]:p.mkdir(mode=0o700,parents=True)
    (state/'sentinel').write_text('owned fixture')
    held=[]; real_rmtree=shutil.rmtree
    def remove_fixture(path,*args,**kw):
        path=Path(path); old=(path/'control.lock').stat().st_ino if path==state else None
        real_rmtree(path,*args,**kw)
        if path==state:
            path.mkdir(mode=0o700)
            fd=os.open(path/'control.lock',os.O_RDWR|os.O_CREAT,0o600)
            fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            held.append(fd)
            results['wipe_lock_split']={'new_controller_acquired_while_wipe_holds_old_fd':True,'old_inode':old,'new_inode':os.fstat(fd).st_ino,'distinct_inode':old!=os.fstat(fd).st_ino}
    plan={'base':str(base),'state':str(state),'pending_gates':[],'remove_plugin':False,'entries':[{'path':str(state),'kind':'tree'}]}
    with patch.dict(os.environ,{'HOME':str(home)}),patch.object(uninstall,'require_idle',return_value=IDLE),patch.object(uninstall.shutil,'rmtree',side_effect=remove_fixture):
        uninstall.apply_plan(plan,home)
    for fd in held:os.close(fd)

# Reach only the legacy install preflight: dependency function is a log-only mock,
# every filesystem preparer/lock is a no-op, and the real require_idle is mocked
# to reject active output. No actual package install or filesystem removal.
order=[]
class RejectAfterDependencies(Exception):pass
with patch.object(installer.os,'getuid',return_value=1000),patch.object(installer,'verify_payload',return_value={'files':{'decky.py':'','decky-install':''}}),patch.object(installer,'load_module',return_value=SimpleNamespace(status=lambda:{'ok':True,'version':'fixture'})),patch.object(installer,'ensure_dependencies',side_effect=lambda:order.append('dependency-mutation-stage')),patch.object(installer,'owned_directory'),patch.object(installer,'require_space'),patch.object(installer,'installation_lock',return_value=contextlib.nullcontext()),patch.object(installer,'require_idle',side_effect=lambda *a,**k:(_ for _ in ()).throw(RejectAfterDependencies())),contextlib.redirect_stdout(io.StringIO()):
    try:installer.install(launch=False)
    except RejectAfterDependencies:order.append('active-output-rejected-after-dependency-stage')
results['legacy_dependency_order']={'order':order}

print(json.dumps(results,indent=2))
