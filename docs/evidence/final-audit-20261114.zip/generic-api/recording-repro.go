package main

import (
 "context"
 "encoding/json"
 "fmt"
 "net/http"
 "net/http/httptest"
 "strings"
 "sync/atomic"
 "time"

 "github.com/gorilla/websocket"
 api "github.com/szmyty/obsgod/pkg/api/v1"
 "github.com/szmyty/obsgod/pkg/automation"
)

type fixture struct { mode string; reads, starts, stops atomic.Int32; active atomic.Bool }
func (f *fixture) serve(w http.ResponseWriter, r *http.Request) {
 c, e := (&websocket.Upgrader{}).Upgrade(w,r,nil); if e != nil {return}; defer c.Close()
 c.WriteJSON(map[string]any{"op":0,"d":map[string]any{"rpcVersion":1,"obsWebSocketVersion":"5.5.0"}})
 var identify any; if c.ReadJSON(&identify)!=nil{return}
 c.WriteJSON(map[string]any{"op":2,"d":map[string]any{"negotiatedRpcVersion":1}})
 for {var q struct{D struct{Type string `json:"requestType"`; ID string `json:"requestId"`} `json:"d"`}; if c.ReadJSON(&q)!=nil{return}; data:=map[string]any{}
  switch q.D.Type {
  case "GetVersion":data=map[string]any{"obsVersion":"33.0.1","obsWebSocketVersion":"5.5.0"}
  case "GetProfileList":data=map[string]any{"currentProfileName":"OBSGod","profiles":[]string{"OBSGod"}}
  case "GetSceneCollectionList":data=map[string]any{"currentSceneCollectionName":"OBSGod","sceneCollections":[]string{"OBSGod"}}
  case "GetCurrentProgramScene":data=map[string]any{"sceneName":"Live"}
  case "GetRecordStatus":n:=f.reads.Add(1); data=map[string]any{"outputActive":f.active.Load(),"outputPaused":false,"outputBytes":1024}; if f.mode=="runtime" || (f.mode=="start" && n==1) || (f.mode=="stop" && n>=3) {delete(data,"outputActive")}
  case "StartRecord":f.starts.Add(1);f.active.Store(true)
  case "StopRecord":f.stops.Add(1);data=map[string]any{"outputPath":"/fixture/still-active.mkv"}
  }
  if c.WriteJSON(map[string]any{"op":7,"d":map[string]any{"requestType":q.D.Type,"requestId":q.D.ID,"requestStatus":map[string]any{"result":true,"code":100},"responseData":data}})!=nil{return}
 }
}
func main(){for _,mode:=range []string{"runtime","start","stop"}{f:=&fixture{mode:mode};f.active.Store(mode!="start");s:=httptest.NewServer(http.HandlerFunc(f.serve));addr:=strings.TrimPrefix(s.URL,"http://");ctx,cancel:=context.WithTimeout(context.Background(),3*time.Second);var out map[string]any
 if mode=="stop" {c,e:=api.Connect(ctx,api.Connection{Address:addr});if e!=nil{panic(e)};path,e:=c.StopRecording(ctx,api.Approval{Recording:true});out=map[string]any{"case":mode,"returned_path":path,"returned_error":fmt.Sprint(e),"server_recording_still_active":f.active.Load(),"stop_requests":f.stops.Load(),"status_reads":f.reads.Load()};c.Close()} else {c,e:=automation.Connect(ctx,automation.Config{Address:addr});if e!=nil{panic(e)};if mode=="runtime"{state,e:=c.RuntimeStatus(ctx);out=map[string]any{"case":mode,"returned_recording":state.Recording,"returned_error":fmt.Sprint(e),"server_recording_still_active":f.active.Load()}} else {e:=c.StartRecording(ctx);out=map[string]any{"case":mode,"returned_error":fmt.Sprint(e),"start_requests_after_unknown":f.starts.Load()}};c.Close()};cancel();s.Close();b,_:=json.Marshal(out);fmt.Println(string(b))}}
