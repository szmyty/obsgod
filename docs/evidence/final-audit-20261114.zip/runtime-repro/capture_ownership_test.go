//go:build linux
package deck
import (
 "context"
 "errors"
 "testing"
 "time"
)
// Audit-only external overlay; source checkout remains unchanged.
func TestAuditCaptureWatchOwnershipRace(t *testing.T) {
 f := newVideoFixture(t)
 f.scene = GameScene
 _, dial := videoClient(t, f)
 p := testPaths(t)
 s := DefaultSettings(); s.CaptureMode = "game"
 loads, changedAt := 0, 0
 stop := errors.New("audit fixture complete")
 err := watchCaptureWith(context.Background(), p, captureWatchDeps{
  load: func(Paths)(Settings,Secrets,error) { loads++; if loads > 1 { return s,Secrets{},stop }; return s,Secrets{},nil },
  connect: dial,
  discover: func(context.Context) GameIdentity { f.mu.Lock(); f.collection = "Ordinary collection"; changedAt = len(f.requests); f.mu.Unlock(); return GameIdentity{State:"idle"} },
  interval: time.Millisecond,
 })
 if !errors.Is(err,stop) { t.Fatalf("unexpected exit %v",err) }
 f.mu.Lock(); defer f.mu.Unlock()
 for _, q := range f.requests[changedAt:] {
  t.Logf("after collection switched: %s",q.Type)
  if q.Type == "SetCurrentProgramScene" {
   t.Logf("REPRODUCED: changed ordinary collection scene to %v without ownership recheck",q.Data["sceneName"])
   return
  }
 }
 t.Fatal("candidate was not reproduced")
}

func TestAuditCaptureWatchDisablesMixerEnabledMicrophone(t *testing.T) {
 f := newVideoFixture(t)
 f.inputs[MicAudio] = &videoInput{kind:"pulse_input_capture",settings:map[string]any{"device_id":"fixture-mic"}}
 for _, scene := range []string{IdleScene,GameScene} { f.next++; f.scenes[scene][MicAudio] = &videoItem{id:f.next,enabled:true} }
 _, dial := videoClient(t,f)
 p := testPaths(t)
 s := DefaultSettings(); s.CaptureMode = "game" // legacy microphone setting false
 pref := defaultMixerPreferences(s); pref.MicrophoneEnabled = true; pref.MicrophoneMuted = false
 if err := writeJSON(mixerPreferencesPath(p),pref); err != nil { t.Fatal(err) }
 stop := errors.New("audit fixture complete"); loads := 0
 err := watchCaptureWith(context.Background(), p, captureWatchDeps{
  load: func(Paths)(Settings,Secrets,error) { loads++; if loads > 2 { return s,Secrets{},stop }; return s,Secrets{},nil },
  connect: dial,
  discover: func(context.Context) GameIdentity { return GameIdentity{AppID:42,State:"running"} },
  interval: time.Millisecond,
 })
 if !errors.Is(err,stop) { t.Fatalf("unexpected exit %v",err) }
 observed, err := MixerSettings(p,s); if err != nil || !observed.MicrophoneEnabled { t.Fatalf("mixer preference changed: %+v %v",observed,err) }
 f.mu.Lock(); defer f.mu.Unlock()
 for _, scene := range []string{IdleScene,GameScene} {
  if f.scenes[scene][MicAudio].enabled { t.Fatalf("candidate not reproduced: microphone still enabled in %s",scene) }
  t.Logf("REPRODUCED: microphone_enabled=true, legacy microphone=false; capture observer disabled microphone scene item in %s",scene)
 }
}
