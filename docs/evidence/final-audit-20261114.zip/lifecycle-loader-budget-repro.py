"""Emulate pinned Decky's five-second backend kill; only disposable fake helpers."""
import json, os
from pathlib import Path
import signal, subprocess, sys, tempfile, time
SOURCE=Path('/workspace/obsgod/steamdeck/decky/main.py')
with tempfile.TemporaryDirectory(prefix='obsgod-loader-budget-') as temp:
    root=Path(temp); (root/'bin').mkdir(); events=root/'events.jsonl'; marker=root/'late-start'
    helper=root/'bin/obsgod'
    helper.write_text('#!'+sys.executable+'\n'+'''import json, os, sys, time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
action=sys.argv[-1]
with (root/'events.jsonl').open('a') as stream:stream.write(json.dumps({'action':action,'pid':os.getpid()})+'\\n')
if action=='start':
 time.sleep(6)
 (root/'late-start').write_text('owned fake child completed start after backend kill')
if action=='mixer':time.sleep(8)
print(json.dumps({'ok':True,'state':'stopped','output_known':True,'process':'absent','stream':{'active':False},'recording':False,'media':{'known':True,'replay_active':False}}))
'''.replace("+'\\n'", "+'\\n'"))
    # Replace the source's escaped line terminator with an actual Python escape.
    helper.write_text(helper.read_text().replace("+'\\\\n'", "+'\\n'"))
    helper.chmod(0o700)
    backend=root/'backend.py'
    backend.write_text('''import asyncio,importlib.util,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('backend',sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
async def run():
 p=m.Plugin();p._plugin_root=lambda:Path(sys.argv[2]);p._child_environment=lambda:dict(os.environ)
 task=asyncio.create_task(p.start())
 while p.pending is None:await asyncio.sleep(.001)
 await p._unload()
 await task
asyncio.run(run())
''')
    process=subprocess.Popen([sys.executable,str(backend),str(SOURCE),str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    try:
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            if events.exists() and 'mixer' in events.read_text():break
            time.sleep(.01)
        else:raise RuntimeError('fake mixer did not enter')
        before=time.monotonic();time.sleep(5)
        process.kill(); process.wait(timeout=2)
        time.sleep(1.25)
        calls=[json.loads(line) for line in events.read_text().splitlines()]
        result={'loader_contract_seconds':5,'backend_killed_after_seconds':round(time.monotonic()-before-1.25,2),'fake_child_actions': [row['action'] for row in calls],'stop_invoked_before_backend_kill':any(row['action']=='stop' for row in calls),'fake_start_completed_after_backend_kill':marker.exists(),'scope':'fake executable in temporary directory; no OBS/Decky/Flatpak/network invoked'}
        print(json.dumps(result,indent=2))
    finally:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        process.wait(timeout=2)
