from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import threading,json,hashlib
from playwright.sync_api import sync_playwright,expect
out=Path(__file__).parent
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(out/'fixture')))
threading.Thread(target=server.serve_forever,daemon=True).start()
report={'baseline':'12ef52f9d22a7c1101f8743094325f66e3948270','runtime_source':'378b46cb8c4a9281f9d6890b2e13b223650626d5','source_frontend_diff':'none','host':'simulated Decky host, native HTML controls; no real Steam controller','viewport':{'width':400,'height':800},'errors':[],'cases':{}}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport=report['viewport'])
 page.on('pageerror',lambda e:report['errors'].append(str(e)))
 page.goto(f'http://127.0.0.1:{server.server_port}')
 start=page.get_by_role('button',name='Start streaming',exact=True)
 expect(start).to_be_enabled()
 def measure(label):
  page.evaluate('window.scrollTo(0,0)')
  value=page.evaluate('''()=>{const buttons=Array.from(document.querySelectorAll('button'));const start=buttons.find(x=>x.textContent==='Start streaming'),stop=buttons.find(x=>x.textContent==='Stop streaming / recover'||x.textContent==='Stop streaming');return {start_y:start.getBoundingClientRect().top,stop_y:stop.getBoundingClientRect().top,document_height:document.documentElement.scrollHeight,buttons_before_start:buttons.slice(0,buttons.indexOf(start)).map(x=>x.textContent),enabled_buttons_before_start:buttons.slice(0,buttons.indexOf(start)).filter(x=>!x.disabled).map(x=>x.textContent),horizontal_overflow:document.documentElement.scrollWidth>window.innerWidth};}''')
  page.screenshot(path=str(out/(label+'-viewport.png')))
  page.screenshot(path=str(out/(label+'-full.png')),full_page=True)
  report['cases'][label]=value
 measure('configured-idle')
 page.evaluate('fixture.active=true;fixture.bytes=1000')
 page.get_by_role('button',name='Refresh status',exact=True).click()
 expect(page.get_by_role('button',name='Stop streaming / recover',exact=True)).to_be_enabled()
 expect(page.get_by_text('OBS streaming',exact=True)).to_be_visible()
 page.get_by_role('button',name='Refresh settings',exact=True).click()
 expect(page.get_by_role('button',name='Close managed OBS to edit settings…',exact=True)).to_have_count(0)
 measure('streaming')
 # A rejected recovery request should be visible even without opening health details.
 page.evaluate('fixture.recoveryFailure=true')
 recovery=page.get_by_role('button',name='Retry bounded audio/capture recovery',exact=True)
 recovery.click()
 expect(recovery).to_be_enabled()
 page.wait_for_timeout(100)
 report['cases']['recovery-error-collapsed']={'failure_text_visible':page.get_by_text('Recovery could not be confirmed; inspect OBS.',exact=True).count(),'body_has_failure': 'Recovery could not be confirmed' in page.locator('body').inner_text(),'toasts':page.evaluate('fixture.toasts'),'call_count':page.evaluate('fixture.calls.retry_recovery')}
 recovery.scroll_into_view_if_needed()
 page.screenshot(path=str(out/'recovery-error-collapsed.png'))
 # Provider guide throws without giving the user a local failure message.
 page.evaluate('fixture.linkFailure=true')
 page.get_by_role('button',name='Open Kick setup guide',exact=True).click()
 page.wait_for_timeout(100)
 report['cases']['guide-navigation-error']={'page_errors':list(report['errors']),'visible_recovery_message':page.get_by_text('Could not open',exact=False).count(),'link_attempts':page.evaluate('fixture.externalLinks')}
 # Clip loading presents a completed-empty message before the observation resolves.
 page.evaluate('fixture.active=false;fixture.clipListDelay=true')
 page.get_by_role('button',name='Refresh status',exact=True).click()
 page.get_by_role('button',name='Browse saved clips',exact=True).click()
 expect(page.get_by_text('No finalized managed clips listed.',exact=False)).to_be_visible()
 report['cases']['clips-loading-empty']={'pending':page.evaluate('typeof fixture.finishClipList === "function"'),'visible_empty':page.get_by_text('No finalized managed clips listed.',exact=False).inner_text()}
 page.get_by_text('No finalized managed clips listed.',exact=False).scroll_into_view_if_needed()
 page.screenshot(path=str(out/'clips-loading-empty.png'))
 page.evaluate('fixture.finishClipList()')
 # First-run top-of-page still has main control below dependency and full setup.
 page.reload()
 expect(start).to_be_enabled()
 page.evaluate('fixture.configured=false;fixture.obsAbsent=true;fixture.dependencyReady=false;fixture.dependencyState="setup_required";fixture.dependencyCanInstall=true')
 page.get_by_role('button',name='Check setup status',exact=True).click()
 page.get_by_role('button',name='Refresh settings',exact=True).click()
 page.get_by_role('button',name='Refresh status',exact=True).click()
 expect(start).to_be_disabled()
 measure('first-run')
 browser.close()
server.shutdown()
report['screenshots']=[p.name for p in out.glob('*.png')]
(out/'browser-findings.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
