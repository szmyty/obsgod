import datetime,hashlib,importlib.metadata,json,platform,subprocess,sys
from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import threading
from playwright.sync_api import sync_playwright
ROOT=Path('/workspace/obsgod');OUT=Path(__file__).parent;REV='af7a20fdd0c62404e9b11d540fb605368e269380'
def source():
 return {'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),'dirty':bool(subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True).strip())}
start=source();assert start['revision']==REV and start['dirty'] is False,start
path=ROOT/'branding/aurora/index.html'
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(path.parent)))
threading.Thread(target=server.serve_forever,daemon=True).start()
origin='http://127.0.0.1:'+str(server.server_port);url=origin+'/index.html';errors=[];requests=[];external=[];cases=[];screens={}
receipt={'schema':'deckystream.aurora-gallery-browser/v1','revision':REV,'source_before':start,'result':'failed','cases':cases,'external_requests':external,'page_errors':errors,'python':platform.python_version(),'platform':platform.platform(),'playwright':importlib.metadata.version('playwright'),'browser':subprocess.check_output(['/usr/bin/chromium','--version'],text=True).strip(),'gallery_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'command':'python3 scripts/run-user-tests.py --output-root PRIVATE_GALLERY -- PRIVATE_GALLERY/check.py','limits':'Identical source HTML served on loopback: offline-contained asset/decode/download/layout evidence only. Direct file-URL rendering is unavailable under managed browser policy (separate original failed attempt preserved); not source export repeat, real Steam Deck/controller rendering, rights/adoption, hosted CI or release acceptance.'}
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  ctx=browser.new_context(accept_downloads=True)
  page=ctx.new_page();page.on('pageerror',lambda error:errors.append(str(error)))
  def route_request(route):
   value=route.request.url;requests.append(value)
   if value.startswith(origin+'/') or value.startswith('data:image/png;base64,'):route.continue_()
   else:external.append(value);route.abort()
  page.route('**/*',route_request)
  for label,width,height in [('desktop',1280,800),('mobile',390,844)]:
   page.set_viewport_size({'width':width,'height':height});page.goto(url,wait_until='load')
   assert page.locator('script').count()==0
   page.wait_for_function('[...document.images].length===16&&[...document.images].every(image=>image.complete&&image.naturalWidth>0)')
   images=page.locator('img').evaluate_all('images=>images.map(image=>({name:image.alt,width:image.naturalWidth,height:image.naturalHeight,declaredWidth:Number(image.getAttribute("width")),declaredHeight:Number(image.getAttribute("height")),data:image.src.startsWith("data:image/png;base64,")}))')
   assert len(images)==16 and all(i['data'] and i['width']==i['declaredWidth'] and i['height']==i['declaredHeight'] for i in images)
   assert all(any(i['name']==f'web/favicon-{size}.png' and i['width']==size and i['height']==size for i in images) for size in (16,24,32,64))
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
   links=page.locator('a').evaluate_all('links=>links.map(a=>({href:a.href,name:a.download}))')
   assert len(links)==16 and all(x['href'].startswith('data:image/png;base64,') and x['name'].endswith('.png') for x in links)
   image=OUT/('gallery-'+label+'.png');page.screenshot(path=str(image),full_page=False);screens[image.name]=hashlib.sha256(image.read_bytes()).hexdigest()
   cases.append({'name':label,'viewport':{'width':width,'height':height},'result':'passed','image_count':len(images),'images':images,'download_count':len(links),'horizontal_overflow':False})
  with page.expect_download() as pending:
   page.locator('a[download="favicon-32.png"]').click()
  download=pending.value;target=OUT/'download-favicon-32.png';download.save_as(str(target));assert download.suggested_filename=='favicon-32.png';assert target.read_bytes()==(ROOT/'branding/aurora/web/favicon-32.png').read_bytes()
  cases.append({'name':'ordinary-png-download','result':'passed','filename':download.suggested_filename,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
  assert not external and not errors
  browser.close()
 after=source();assert after==start,after
 receipt.update(result='passed',source_after=after,screenshots=screens,request_count=len(requests),transport='loopback HTTP; source HTML byte-identical',file_url_status='unavailable: ERR_BLOCKED_BY_ADMINISTRATOR; no policy override attempted',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
except BaseException as error:
 receipt.update(error_type=type(error).__name__,error=str(error),source_after=source());raise
finally:
 server.shutdown()
 (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'result':receipt['result'],'revision':REV,'cases':len(cases),'images_per_viewport':16,'external_requests':len(external),'page_errors':len(errors)}))
