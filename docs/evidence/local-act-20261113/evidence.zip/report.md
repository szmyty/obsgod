# Local CI report

Source: `cf12abe6c620dcbea3b806d1aa63a4715adea26a` · Local result: **passed** · Overall: **partial**.

Six supported Linux ACT jobs are separate from PR/provider, native-platform and physical-device gates.

| Job | Status | Evidence |
| --- | --- | --- |
| build | passed | [20261113T231857Z-build.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T231857Z-build.json) |
| coverage | passed | [20261113T231935Z-coverage.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T231935Z-coverage.json) |
| lint | passed | [20261113T231812Z-lint.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T231812Z-lint.json) |
| snapshot | passed | [20261113T232013Z-snapshot.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232013Z-snapshot.json) |
| docs | passed | [20261113T232106Z-docs.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232106Z-docs.json) |
| candidate | passed | [20261113T232124Z-candidate.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232124Z-candidate.json) |

## Retained runs

Raw outcomes, counts, commands and source/client/runner/workflow/configuration hashes are retained in report.json.

| Run | Recorded / raw | Integrity / clean | Evidence |
| --- | --- | --- | --- |
| 20261113T223849Z-lint | passed / passed | verified / True | [20261113T223849Z-lint.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T223849Z-lint.json) · [20261113T223849Z-lint.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T223849Z-lint.log) |
| 20261113T223942Z-build | passed / passed | verified / True | [20261113T223942Z-build.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T223942Z-build.json) · [20261113T223942Z-build.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T223942Z-build.log) |
| 20261113T224018Z-coverage | passed / passed | verified / True | [20261113T224018Z-coverage.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T224018Z-coverage.json) · [20261113T224018Z-coverage.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T224018Z-coverage.log) |
| 20261113T224054Z-snapshot | passed / passed | verified / True | [20261113T224054Z-snapshot.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T224054Z-snapshot.json) · [20261113T224054Z-snapshot.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T224054Z-snapshot.log) |
| 20261113T224148Z-docs | passed / passed | verified / True | [20261113T224148Z-docs.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T224148Z-docs.json) · [20261113T224148Z-docs.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T224148Z-docs.log) |
| 20261113T230426Z-candidate | passed / passed | verified / True | [20261113T230426Z-candidate.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T230426Z-candidate.json) · [20261113T230426Z-candidate.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T230426Z-candidate.log) |
| 20261113T231812Z-lint | passed / passed | verified / True | [20261113T231812Z-lint.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T231812Z-lint.json) · [20261113T231812Z-lint.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T231812Z-lint.log) |
| 20261113T231857Z-build | passed / passed | verified / True | [20261113T231857Z-build.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T231857Z-build.json) · [20261113T231857Z-build.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T231857Z-build.log) |
| 20261113T231935Z-coverage | passed / passed | verified / True | [20261113T231935Z-coverage.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T231935Z-coverage.json) · [20261113T231935Z-coverage.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T231935Z-coverage.log) |
| 20261113T232013Z-snapshot | passed / passed | verified / True | [20261113T232013Z-snapshot.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232013Z-snapshot.json) · [20261113T232013Z-snapshot.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232013Z-snapshot.log) |
| 20261113T232106Z-docs | passed / passed | verified / True | [20261113T232106Z-docs.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232106Z-docs.json) · [20261113T232106Z-docs.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232106Z-docs.log) |
| 20261113T232124Z-candidate | passed / passed | verified / True | [20261113T232124Z-candidate.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232124Z-candidate.json) · [20261113T232124Z-candidate.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232124Z-candidate.log) |
| 20261113T232924Z-lint | passed / passed | verified / True | [20261113T232924Z-lint.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232924Z-lint.json) · [20261113T232924Z-lint.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T232924Z-lint.log) |
| 20261113T233019Z-dependency-review-live-refs | unavailable / failed | verified / True | [20261113T233019Z-dependency-review-live-refs.json](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T233019Z-dependency-review-live-refs.json) · [20261113T233019Z-dependency-review-live-refs.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T233019Z-dependency-review-live-refs.log) |

## Actionable failure groups

### dependency-review: Main Review dependency changes against GitHub's advisory database

Classification: **provider_gate** · Raw execution: **failed** · open.

Reproduction (review captured context/placeholders before running):

```sh
/workspace/.obsgod-tools/pkg/bin/act --directory /workspace/obsgod --bind --env-file /dev/null --secret-file /dev/null --input-file /dev/null --container-daemon-socket /var/run/docker.sock --network bridge --concurrent-jobs 1 --container-options '--mount type=bind,src=/etc/ssl/certs/ca-certificates.crt,dst=/run/obsgod-ca.pem,readonly --mount type=bind,src=/workspace/.obsgod-tools/completion/act/apt-cloud-ca.conf,dst=/etc/apt/apt.conf.d/99-obsgod-cloud-ca,readonly --mount type=bind,src=/workspace/.obsgod-tools/completion/act/tmp,dst=/workspace/.obsgod-tools/completion/act/tmp --add-host proxy:172.31.2.77 --add-host proxy:172.31.2.77' --action-cache-path /workspace/.obsgod-tools/completion/act/actions --artifact-server-path /workspace/.obsgod-tools/completion/act/artifacts --artifact-server-addr 172.26.91.249 --artifact-server-port 34567 --env NODE_EXTRA_CA_CERTS=/run/obsgod-ca.pem --env NODE_USE_ENV_PROXY=1 --env SSL_CERT_FILE=/run/obsgod-ca.pem --env GIT_SSL_CAINFO=/run/obsgod-ca.pem --env PIP_CERT=/run/obsgod-ca.pem --env CODEX_PROXY_CERT=/run/obsgod-ca.pem --env TMPDIR=/workspace/.obsgod-tools/completion/act/tmp --env OBSGOD_ACT_TEMP=/workspace/.obsgod-tools/completion/act/tmp --local-repository actions/checkout@11d5960a326750d5838078e36cf38b85af677262=/workspace/.obsgod-tools/completion/act/action-sources/actions-checkout-11d5960a326750d5838078e36cf38b85af677262 --local-repository actions/dependency-review-action@a1d282b36b6f3519aa1f3fc636f609c47dddb294=/workspace/.obsgod-tools/completion/act/action-sources/actions-dependency-review-action-a1d282b36b6f3519aa1f3fc636f609c47dddb294 --local-repository actions/setup-go@40f1582b2485089dde7abd97c1529aa768e1baff=/workspace/.obsgod-tools/completion/act/action-sources/actions-setup-go-40f1582b2485089dde7abd97c1529aa768e1baff --local-repository actions/setup-node@49933ea5288caeca8642d1e84afbd3f7d6820020=/workspace/.obsgod-tools/completion/act/action-sources/actions-setup-node-49933ea5288caeca8642d1e84afbd3f7d6820020 --local-repository actions/setup-python@a26af69be951a213d495a4c3e4e4022e16d87065=/workspace/.obsgod-tools/completion/act/action-sources/actions-setup-python-a26af69be951a213d495a4c3e4e4022e16d87065 --local-repository actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02=/workspace/.obsgod-tools/completion/act/action-sources/actions-upload-artifact-ea165f8d65b6e75b540449e92b4886f43607fa02 --local-repository goreleaser/goreleaser-action@e435ccd777264be153ace6237001ef4d979d3a7a=/workspace/.obsgod-tools/completion/act/action-sources/goreleaser-goreleaser-action-e435ccd777264be153ace6237001ef4d979d3a7a --env 'HTTP_PROXY=[injected]' --env 'HTTPS_PROXY=[injected]' --env 'NO_PROXY=[injected]' --env 'http_proxy=[injected]' --env 'https_proxy=[injected]' --env 'no_proxy=[injected]' pull_request -W .github/workflows/lint.yml -j dependency-review --eventpath /workspace/.obsgod-tools/completion/act/cf12abe6-live-commit-pr-fixture.json
```

1. Confirm a clean checkout of cf12abe6c620dcbea3b806d1aa63a4715adea26a.
2. Restore the repository's real dependency-review/graph/API capability with its owner; rerun the real PR check. Synthetic act cannot replace it.
3. Compare new evidence without overwriting these receipts; review private logs before sharing.

Evidence: [20261113T233019Z-dependency-review-live-refs.log](/workspace/.obsgod-tools/act-audit-20261113/completed-cf12-state/20261113T233019Z-dependency-review-live-refs.log:18)

## Evidence errors

None.

## Separate gates

PR static runs: 20261113T232924Z-lint.

- dependency-review (real PR/provider): **unavailable** (raw failed).
- native Windows 2025: **unrun**.
- native macOS 15: **unrun**.
- Linux arm64 runtime: **unrun**.
- actual Steam Deck/Flatpak/Gamescope/controller/audio: **unrun**.
- provider viewer reception: **unrun**.
- hosted GitHub CI/reviews/artifact delivery: **unrun**.

- Only verified adjacent logs are parsed. Counts describe observed events/summaries, not unlogged tests.
- Missing legacy provenance hashes remain null; current files do not reconstruct historical binaries/configuration.
- Passed-job error text may be an expected negative control: it remains diagnostic, not a failure finding.
- Private logs/reports require human review before sharing. No issue, provider action or publication is performed.
