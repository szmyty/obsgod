# Local CI report

Source: `9038e23e1a7bfe79c0a5731546f1d3e1a1a74e41` · Local result: **passed** · Overall: **partial**.

Six supported Linux ACT jobs are separate from PR/provider, native-platform and physical-device gates.

| Job | Status | Evidence |
| --- | --- | --- |
| build | passed | [20261114T231436Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231436Z-build.json) |
| coverage | passed | [20261114T231518Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231518Z-coverage.json) |
| lint | passed | [20261114T231345Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231345Z-lint.json) |
| snapshot | passed | [20261114T231609Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231609Z-snapshot.json) |
| docs | passed | [20261114T231739Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231739Z-docs.json) |
| candidate | passed | [20261114T231756Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231756Z-candidate.json) |

## Retained runs

Raw outcomes, counts, commands and source/client/runner/workflow/configuration hashes are retained in report.json.

| Run | Recorded / raw | Integrity / clean | Evidence |
| --- | --- | --- | --- |
| 20261114T231345Z-lint | passed / passed | verified / True | [20261114T231345Z-lint.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231345Z-lint.json) · [20261114T231345Z-lint.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231345Z-lint.log) |
| 20261114T231436Z-build | passed / passed | verified / True | [20261114T231436Z-build.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231436Z-build.json) · [20261114T231436Z-build.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231436Z-build.log) |
| 20261114T231518Z-coverage | passed / passed | verified / True | [20261114T231518Z-coverage.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231518Z-coverage.json) · [20261114T231518Z-coverage.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231518Z-coverage.log) |
| 20261114T231609Z-snapshot | passed / passed | verified / True | [20261114T231609Z-snapshot.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231609Z-snapshot.json) · [20261114T231609Z-snapshot.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231609Z-snapshot.log) |
| 20261114T231739Z-docs | passed / passed | verified / True | [20261114T231739Z-docs.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231739Z-docs.json) · [20261114T231739Z-docs.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231739Z-docs.log) |
| 20261114T231756Z-candidate | passed / passed | verified / True | [20261114T231756Z-candidate.json](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231756Z-candidate.json) · [20261114T231756Z-candidate.log](/workspace/.obsgod-tools/actions-current-audit/local/act-state/20261114T231756Z-candidate.log) |

## Actionable failure groups

No verified failed-run findings. This does not complete unrun or unavailable checks.
## Evidence errors

None.

## Separate gates

PR static runs: unrun.

- dependency-review (real PR/provider): **unrun**.
- native Windows 2025: **unrun**.
- native macOS 15: **unrun**.
- Linux arm64 runtime: **unrun**.
- actual Steam Deck/Flatpak/Gamescope/controller/audio: **unrun**.
- provider viewer reception: **unrun**.
- hosted GitHub CI/reviews/artifact delivery: **unrun**.

- Only verified adjacent logs are parsed. Counts describe observed events/summaries, not unlogged tests.
- Missing legacy provenance hashes remain null; current files do not reconstruct historical binaries/configuration.
- Passed-job error text may be an expected negative control: it remains diagnostic, not a failure finding.
- Private logs/reports require human review before sharing. No issue, provider action or publication is performed.
