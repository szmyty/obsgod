set -eu
cat /etc/os-release > /evidence/os-release.txt
find /etc/apt -type f \( -name '*.list' -o -name '*.sources' \) -print0 | sort -z | xargs -0 sha256sum > /evidence/apt-sources-before.sha256
apt-get -o Acquire::https::CaInfo=/run/cloud-ca.pem -o Acquire::Retries=0 update
apt-get -o Acquire::https::CaInfo=/run/cloud-ca.pem -o Acquire::Retries=0 install -y --no-install-recommends fish
find /etc/apt -type f \( -name '*.list' -o -name '*.sources' \) -print0 | sort -z | xargs -0 sha256sum > /evidence/apt-sources-after.sha256
fish --version > /evidence/fish-version.txt
dpkg-query --show --showformat='${Package} ${Version}\n' fish > /evidence/fish-package.txt
mkdir -p /tmp/fish-home
export HOME=/tmp/fish-home
fish --no-execute /validation/completion.fish
fish --no-config -c 'source /validation/completion.fish; complete -C "obsgod "' > /evidence/dynamic-completions.txt
