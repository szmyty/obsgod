# Decky Stream compact qualification evidence

Selected clean source: 1a482808a8281c8bce092cea057df758836b34e9
Candidate: 0.1.0-deck.9

This bundle retains actual commands, execution logs, source/input hashes and
sanitized JSON proofs for two complete local ACT sequences, PR static checks
and the explicit provider dependency-review attempt. Inspect matrices/ first.
The repository entry point and trust boundaries are documented at:
https://github.com/szmyty/obsgod/blob/1a482808a8281c8bce092cea057df758836b34e9/docs/local-ci.md

Product runtime/plugin/updater/SBOM/provenance artifacts are delivered separately.
The large local ACT artifact ZIPs, screenshots, encoded media, private fixture
homes/configuration and raw historical logs are intentionally excluded. Their
retained hashes/inventories remain inspectable. Historical attempts do not
qualify this source. The selected 14 product/audit files match across both runs;
local service ZIPs include variable browser evidence and differ accordingly.

The runner already redacted URL userinfo while logging. evidence-index.json
records each retained input hash and the hash of its public sanitized bytes,
plus any additional rules applied here. Matrix hashes identify retained inputs;
use the public_sanitized_sha256 index for the bytes in this ZIP if they differ.
Native proof entries also retain the
original pre-sanitization hash captured by the parent execution registry. No
unredacted pre-run log is invented. Only synthetic fixture credentials were
used in these checks; this filtering is not a guarantee for arbitrary logs.

Linux Docker/OBS30.2.3/PipeWire/PulseAudio/Xvfb and browser fixtures do not prove
physical Steam Deck/Flatpak/OBS33/Gamescope/controller/headset/provider behavior.
Cross builds are not native macOS/Windows execution. Provider/hosted GitHub
services, required reviews, owner signing/publisher policy and publication gates
remain explicit. No release/deployment/signature or stable support is claimed.
