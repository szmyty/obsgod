# Proposed Decky Stream kit

Human creative and rights approval is pending. Do not install as production branding.

SVG masters are editable; PNGs, when present, use the locked Inkscape/font. Native Decky uses its theme and a monochrome icon. A quarter-mark clear space and 16px draft minimum are proposals requiring actual device review. No animation, third-party logos, final organization, trademark clearance or publication is implied. The wordmark uses DejaVu Sans; see licenses/DejaVu.txt. Mark geometry was AI-assisted original work by OpenAI Codex for this repository. Owner must decide rights/license before public use. See metadata/rights-and-sources.json.

Run python3 scripts/generate-brand-kit.py --raster --check with the same toolchain for drift verification. Delete only a known generated kit directory to rebuild after a source change; do not change manifest hashes by hand.
