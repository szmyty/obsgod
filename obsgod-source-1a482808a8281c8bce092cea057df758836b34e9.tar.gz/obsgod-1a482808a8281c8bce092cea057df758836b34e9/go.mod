module github.com/szmyty/obsgod

go 1.23.0

toolchain go1.27.4

require (
	github.com/andreykaipov/goobs v1.8.3
	github.com/muesli/coral v1.0.0
)

require (
	github.com/buger/jsonparser v1.1.2 // indirect
	github.com/gorilla/websocket v1.5.3 // indirect
	github.com/hashicorp/logutils v1.0.0 // indirect
	github.com/inconshreveable/mousetrap v1.0.0 // indirect
	github.com/mitchellh/mapstructure v1.5.0 // indirect
	github.com/mmcloughlin/profile v0.1.1 // indirect
	github.com/nu7hatch/gouuid v0.0.0-20131221200532-179d4d0c4d8d // indirect
	github.com/spf13/pflag v1.0.5 // indirect
)
